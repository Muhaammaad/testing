class HomeController < ApplicationController
  def pages
  end
end
