class PagesController < ApplicationController
  def home
  	if user_signed_in?

  	if current_user.admin
  		redirect_to action: :admin
  	else redirect_to action: :doc
  	end
end
  end
  def admin
  end
  def doc
  	search_val = params[:search_val] || ""
	q = "%#{params[:search_val]}%"
	@pdetail = Pdetail.where('first_name LIKE ?', q)

  	#@pdetail= current_user.histori	es
  	respond_to do |format|
      format.html
      format.xml { render :xml => @pdetail.to_xml }
      format.json { render :json => @pdetail.to_json }
    
    end
  end
end
