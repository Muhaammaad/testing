require 'test_helper'

class PdetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
